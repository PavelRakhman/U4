//buttons
const GettAllBtn= document.getElementsByClassName("GetAllBtn")[0]
const AddBtn = document.getElementsByClassName("AddBtn")[0]
const DelBtn = document.getElementsByClassName("DelBtn")[0]
const UpdateBtn=document.getElementsByClassName("UpdateBtn")[0]
const FortuneCookieBtn = document.getElementsByClassName("FortuneCookieSayingBtn")[0]

//response-areas
const FortuneCookieText=document.getElementsByClassName("FortuneCookeText")[0]
const ResponseArea=document.getElementsByClassName("ResponseArea")[0]

//selectMenu
const selectMenu = document.getElementsByClassName("DelSelect")[0]



//event-handlers

FortuneCookieBtn.addEventListener("click", function(evt){
    evt.preventDefault()
    axios
    .get(`http://localhost:5500/api/fortunes`)
    .then(function(response){
        FortuneCookieText.innerHTML = null
        const p= document.createElement("p")
        const t= document.createTextNode(response.data)
        p.appendChild(t)
        FortuneCookieText.appendChild(p)
    })
    .catch(function(error)
    {
        FortuneCookieText.innerHTML = null
        FortuneCookieText.innerHTML = error    
    })
})

selectMenu.addEventListener("click",function(evt){
    evt.preventDefault()
    selectMenu.innerHTML=null
axios.get(`http://localhost:5500/api/users`)
.then(function(response)
{
    let data=response.data
    
    data.forEach(element => {
        const newOpt = document.createElement("option")
    const optionText = document.createTextNode(`${element.params.fname}' ${element.params.lname}`)
    newOpt.innerHTML = optionText
    selectMenu.appendChild(newOpt)
    });
})
.catch(function(error)
{
    ResponseArea.innerHTML=null
    ResponseArea.innerHTML=error
})
})
