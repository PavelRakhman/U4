const express=require("express")
const cors = require("cors")
const app = express()
const FortuneCookies=[
    'A fanatic is one who cannot change his mind and will not change the subject',
    'He who throws dirt is losing ground',
    ' conclusion is simply the place where you got tired of thinking',
    'Some men dream of fortunes, others dream of cookies',
    'The road to riches is paved with homework',
    'You can always find happiness at work on Friday',
    'He who laughs at himself never runs out of things to laugh at',
'Never forget a friend. Especially if he owes you',
    'Actions speak louder than fortune cookies',
    'Fortune not found? Abort, Retry, Ignore',
    'Only listen to the fortune cookie; disregard all other fortune telling units',
    'Don’t let statistics do a number on you'
]






let users =[
    {fname:"Salman", lname: "Jibril"},
    {fname:"John", lname:"Marita"},
    {fname:"Amy", lname:"Brennan"},
    {fname:"Alana", lname:"John"}
]
app.use(express.json())
app.use(cors())
app.get('/api/fortunes', (req, res)=>{
    let randomIndex=Math.floor((Math.random()*FortuneCookies.length-1)+1)
    res.status(200).send(FortuneCookies[randomIndex])
})

app.get('/api/users',(req, res)=>{
    res.status(200).send(users)
})
app.listen(5500, ()=>{console.log("Server running on port 5500")})